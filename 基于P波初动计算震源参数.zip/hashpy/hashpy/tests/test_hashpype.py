#/usr/bin/env python
#
# test_hashpype.py -MCW 2013
#

import unittest
from hashpy.hashpype import HashPype


